#include "main.h"

#define OFF 0
#define ON 1

clock currentTime;
clock expTime;


int currentVolume;
int maxVolume;

int opVals[24][4]=
{
    //At startup everything should be set to zero until vals are downloaded
    //{Time of day, valve mode, minutes on, total max vol}
    {0,OFF,0,0},
    {1,OFF,0,0},
    {2,OFF,0,0},
    {3,OFF,0,0},
    {4,OFF,0,0},
    {5,OFF,0,0},
    {6,OFF,0,0},
    {7,OFF,0,0},
    {8,ON,5,5},
    {9,ON,6,11},
    {10,ON,7,18},
    {11,ON,8,26},
    {12,ON,9,35},
    {13,ON,10,45},
    {14,ON,9,54},
    {15,ON,8,62},
    {16,ON,7,69},
    {17,ON,6,75},
    {18,OFF,0,75},
    {19,OFF,0,75},
    {20,OFF,0,75},
    {21,OFF,0,75},
    {22,OFF,0,75},
    {23,OFF,0,75}
};

void fsmIfaceWaterControl_updateOpVals(){
    //TODO
    //Update the operation vals based on Info coming from mc200
    UART_UartPutString("updateOpVals\n\r");
}

void fsmIfaceWaterControl_setExpTime(){
    currentTime = getTime();
    expTime = currentTime;
    int operationMins = opVals[currentTime.hours][1];
       
    expTime.mins += operationMins;
    if(expTime.mins >= 60){
        expTime.hours+=1;
        expTime.mins-=60;
    }
}

sc_integer fsmIfaceWaterControl_getOpMode(){
    currentTime = getTime();
    int mode = opVals[currentTime.hours][1];
    
    if(currentTime.hours > expTime.hours){
        mode=OFF;
    }
    if(currentTime.hours == expTime.hours && currentTime.mins >= expTime.mins){
        mode=OFF;
    }
        
    UART_UartPutString("checkOpMode  : ");
    UART_UartPutChar(mode);
    UART_UartPutString("\r\n");
    
    //return mode;
    return 1;
}

sc_integer fsmIfaceWaterControl_getCurrentVolume(){
    //TODO
    //make sure that we are not exeeding the maximum volume
    
    UART_UartPutString("checkVolume\n\r");
    return 1;
}

sc_integer fsmIfaceWaterControl_getMaxVolume(){
    //return opVals[getTime().hours][3];
    return 1000;
}    
void fsmIfaceWaterControl_valveOn(){
    //TODO
    //switch valve on
	UART_UartPutString("valveOn\r\n");
}

void fsmIfaceWaterControl_valveOff(){
    //TODO
    //switch valve off
    UART_UartPutString("valveOff\r\n");
	LED_Write(0u);
}

void fsmIfaceWaterControl_sendStats(){
    //TODO
    //send back info about total volume

    LED_Write(1u);
}
