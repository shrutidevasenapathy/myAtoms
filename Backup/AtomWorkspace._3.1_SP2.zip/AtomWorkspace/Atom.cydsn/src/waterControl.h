#include "main.h"

int maxvol;
int volume;
int timeOn;

/*
void fsmIfaceWaterControl_updateOpVals();
void fsmIfaceWaterControl_setExpTime();
int  fsmIfaceWaterControl_getOpMode();
int  fsmIfaceWaterControl_getCurrentVolume();
int  fsmIfaceWaterControl_getMaxVolume();
void fsmIfaceWaterControl_checkVolume();
void fsmIfaceWaterControl_valveOn();
void fsmIfaceWaterControl_valveOff();
void fsmIfaceWaterControl_sendStats();
*/